import React from 'react';
import Projects from './components/Projects';

function App() {
  return (
    <div>
      <Projects />
    </div>
  );
}

export default App;
