import React from "react";
import './AuthorizedUsers.css';

function AuthorizedUsers() {
    return (
        <div className="project-users">
            <button>list, of, authorized, users</button>
        </div>
    );

}

export default AuthorizedUsers